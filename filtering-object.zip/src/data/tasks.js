export const tasks = [
    {
        id: 1,
        title: 'Some task',
        region: 'Switzerland',
        type: 'request',
        description: 'Some cool task',
        active: 1
    },
    {
        id: 2,
        title: 'Some task 2',
        region: 'EMEA',
        type: 'task',
        description: 'Some cool task 2',
        active: 0
    }
];